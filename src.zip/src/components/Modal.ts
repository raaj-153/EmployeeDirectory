export interface Employee{
  firstName: string;
  lastName: string;
  email: string;
  jobTitle: string;
  office: string;
  department: string;
  phoneNumber: string;
  skypeId: string;
  imageUrl: string;
}
