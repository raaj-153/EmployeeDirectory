export const PersonList=()=>{
  return (

    <h2>Bruce Wayne</h2>
  )
}