import React from 'react'

const ModalEditComponent = () => {
  return (
    <div></div>
  )
}

export default ModalEditComponent